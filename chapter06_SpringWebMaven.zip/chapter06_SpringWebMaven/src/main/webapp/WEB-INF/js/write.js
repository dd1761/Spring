//등록
$('#writeBtn').click(function(){
	$('#nameDiv').empty();
	$('#idDiv').empty();
	$('#pwdDiv').empty();
	
	if( $('#name').val() == ''){
		$('#nameDiv').text('이름을 입력해주세요');
	}
	else if($('#id').val()=='') {
		$('#idDiv').text('아이디를 입력해주세요');
	}
	else if($('#pwd').val()=='') {
		$('#pwdDiv').text('패스워드를 입력해주세요');
	}
	else {
		$.ajax({
			type: "post",
			url: '/chapter06_SpringWebMaven/user/write',
			data: $('#writeForm').serialize(),
			success: function(){
				alert('회원가입을 축하합니다.');
				location.href='/chapter06_SpringWebMaven/user/list';
			},
			error: function(err){
				console.log(err);
			}
		});
	}
});

//아이디 중복체크 focusout가 나오면 사용가능 or 불가능


